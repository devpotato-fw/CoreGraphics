//
//  ViewController.m
//  Core Graphics
//
//  Created by wangfang on 2016/9/18.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)chooseButtonPress:(id)sender {

    [self.myDrawView removeFromSuperview];
    
    self.myDrawView = [[DrawView alloc] initWithFrame:CGRectMake(0, 20, CGRectGetMaxX(self.view.bounds), 250)];
    self.myDrawView.backgroundColor = [UIColor clearColor];
    
    UIButton *btn = (UIButton *)sender;
    [self.myDrawView draw:[btn tag]];
    
    [self.view addSubview:self.myDrawView];
}

@end
