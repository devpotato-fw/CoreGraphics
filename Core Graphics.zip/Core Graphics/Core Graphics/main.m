//
//  main.m
//  Core Graphics
//
//  Created by wangfang on 2016/9/18.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
