//
//  DrawView.m
//  Core Graphics
//
//  Created by wangfang on 2016/9/18.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import "DrawView.h"
#import <CoreGraphics/CoreGraphics.h>

@implementation DrawView

-(void)draw:(NSInteger)flag {

    self.flag = flag;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    if (self.flag == 1) {
        /*
         绘制直线
         */
        // 获取上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        //  设置直线宽度
        CGContextSetLineWidth(context, 3.0f);
        // 设置画笔颜色
        CGContextSetStrokeColorWithColor(context, [[UIColor redColor] CGColor]);
        // 设置起始点和终点
        CGContextMoveToPoint(context, 30, 30);
        CGContextAddLineToPoint(context, 150, 150);
        // 绘制直线
        CGContextStrokePath(context);
    } else if (self.flag == 2) {
        /*
         绘制三角形
         */
        // 获取上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        // 设置直线宽度
        CGContextSetLineWidth(context, 3.0f);
        // 设置画笔颜色
        CGContextSetStrokeColorWithColor(context, [[UIColor yellowColor] CGColor]);
        // 设置三角形的三个点，原理就是绘制直线
        CGContextMoveToPoint(context, 30, 30);
        CGContextAddLineToPoint(context, 150, 50);
        CGContextAddLineToPoint(context, 20, 80);
        CGContextAddLineToPoint(context, 30, 30);
        // 绘制路径
        CGContextStrokePath(context);
    } else if (self.flag == 3) {
        /*
         绘制圆形
         */
        // 获取上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        // 设置直线宽度
        CGContextSetLineWidth(context, 5.0f);
        // 设置画笔颜色
        CGContextSetStrokeColorWithColor(context, [[UIColor yellowColor] CGColor]);
        // 设置背景填充颜色
        CGContextSetFillColorWithColor(context, [[UIColor blueColor] CGColor]);
        // 设置绘制圆形的区域
        CGContextAddEllipseInRect(context, CGRectMake(40, 40, 120, 120));
        // 绘制路径
        CGContextFillPath(context);
    } else if (self.flag == 4) {
        /*
         绘制方形
         */
        // 上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        // 设置画笔直线宽度
        CGContextSetLineWidth(context, 2.0f);
        // 设置画笔颜色
        CGContextSetStrokeColorWithColor(context, [[UIColor whiteColor] CGColor]);
        // 设置背景填充色
        CGContextSetFillColorWithColor(context, [[UIColor yellowColor] CGColor]);
        // 设置绘制方形区域
        CGContextAddRect(context, CGRectMake(30, 30, 150, 150));
        // 绘制路径
        CGContextFillPath(context);
    } else if (self.flag == 5) {
        /*
         1 - 直接用UIView方法在view上绘制文字
         */
        // 绘制的文字的内容
        NSString *text = @"钓鱼岛是中国的!!";
        // 设置文字的大小
        UIFont *font = [UIFont boldSystemFontOfSize:28];
        // 设置绘图位置
        CGRect textRect;
        textRect.size = [text sizeWithFont:font];
        textRect.origin.x = 30;
        textRect.origin.y = 80;
        [[UIColor blackColor] setFill];
        // 在view上绘制文字
        [text drawInRect:textRect withFont:font];
        /*
         2 - 用Quartz2D方式绘制文字
         */
        // 获取绘图上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        // 设置绘制的文字
        char *name = "right!";
        // 选择绘制的文字(参数：上下文、字体、大小、转码方式)
        CGContextSelectFont(context, "Helvetica",0.5f , kCGEncodingMacRoman);
        // 设置文字绘制方式(描边、填充、描边填充)
        CGContextSetTextDrawingMode(context,kCGTextFillStroke);
        // 设置画笔和填充颜色
        CGContextSetStrokeColorWithColor(context, [[UIColor redColor] CGColor]);
        CGContextSetFillColorWithColor(context, [[UIColor yellowColor] CGColor]);
        // 绘制文字
        CGContextShowTextAtPoint(context, 50, 250, name, strlen(name));
    } else if (self.flag == 6) {
        /*
         绘制图片-方式1：UIImage自带方式
         */
        UIImage *img1 = [UIImage imageNamed:@"nba-1.png"];
        [img1 drawAtPoint:CGPointMake(30, 30)];
        
        /*
         绘制图片-方式2：Quartz2D方式
         */
        // 获取上下文
        CGContextRef context = UIGraphicsGetCurrentContext();
        // 绘制的图片
        UIImage *img2 = [UIImage imageNamed:@"nba.png"];
        // 使用Quarzt2D绘制的图片是倒置的，使用下方法设置坐标原点和显示比例来改变坐标系
        CGContextTranslateCTM(context, 0.0f, self.frame.size.height);
        CGContextScaleCTM(context, 1.0,-1.0);
        // 在上下文绘制图片
        CGContextDrawImage(context, CGRectMake(220, 130, img2.size.width, img2.size.height), [img2 CGImage]);
    }
}

@end
