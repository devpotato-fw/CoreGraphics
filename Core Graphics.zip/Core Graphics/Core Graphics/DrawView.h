//
//  DrawView.h
//  Core Graphics
//
//  Created by wangfang on 2016/9/18.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawView : UIView

@property (assign, nonatomic) NSInteger flag;

-(void)draw:(NSInteger)flag;

@end
