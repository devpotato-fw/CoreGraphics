//
//  ViewController.h
//  Core Graphics
//
//  Created by wangfang on 2016/9/18.
//  Copyright © 2016年 onefboy. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DrawView.h"

@interface ViewController : UIViewController

@property (strong, nonatomic) DrawView *myDrawView;

- (IBAction)chooseButtonPress:(id)sender;

@end

